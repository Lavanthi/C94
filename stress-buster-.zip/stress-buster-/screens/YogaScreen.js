import  React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class YogaScreen extends React.Component {
  render(){
    return(
      <View style={{
        justifyContent : 'center',
        alignItems: 'center',
        flex:1,
      }}> 
        <Text>Yoga Screen </Text>
      </View>
    )
  }
}
