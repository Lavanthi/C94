import React from 'react';
import {Text, 
        View, 
        SafeAreaView, 
        Platform, 
        StatusBar, 
        StyleSheet, 
        ImageBackground, 
        TouchableOpacity,
        Image
        } from 'react-native';

export default class HomeScreen extends React.Component{
  render(){
    return(
      <View style={styles.container}>
        <SafeAreaView style={styles.droidSafeArea}/>

          <View style={styles.titleBar}>
                        <Text style={styles.titleText}>Stress Buster  </Text>
          </View>

          <TouchableOpacity style={styles.routeCard} onPress={() =>
                        this.props.navigation.navigate("Jokes Screen")
                    }>
                        <Text style={styles.routeText}>Jokes</Text>
                        <Text style={styles.knowMore}>{"Lets go..."}</Text>
                        <Text style={styles.bgDigit}>1</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.routeCard} onPress={() =>
                        this.props.navigation.navigate("Video Screen")
                    }>
                        <Text style={styles.routeText}>Videos</Text>
                        <Text style={styles.knowMore}>{"Lets watch.."}</Text>
                        <Text style={styles.bgDigit}>2</Text>
          </TouchableOpacity>

           <TouchableOpacity style={styles.routeCard} onPress={() =>
                        this.props.navigation.navigate("Yoga Screen")
                    }>
                        <Text style={styles.routeText}>Yoga</Text>
                        <Text style={styles.knowMore}>{"Break a leg, literally"}</Text>
                        <Text style={styles.bgDigit}>3</Text>
          </TouchableOpacity>
      
        
      </View>
        

    )
  }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor:"teal",
        flex: 1,
        width:'100%'
    },
    droidSafeArea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
    },
    backgroundImage: {
        flex: 1,
        resizeMode: 'cover',
    },
    routeCard: {
        flex: 0.25,
        marginLeft: 50,
        marginRight: 50,
        marginTop: 50,
        borderRadius: 30,
        backgroundColor: '#c4f2e9'
    },
    titleBar: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center",
        marginTop:30
    },
    titleText: {
        fontSize: 40,
        fontWeight: "bold",
        color: "white"
    },
    routeText: {
        fontSize: 35,
        fontWeight: "bold",
        color: "#214237",
        marginTop: 30,
        paddingLeft: 30
    },
    knowMore: {
        paddingLeft: 30,
        color: "#214237",
        fontSize: 15
    },
    bgDigit: {
        position: "absolute",
        color: "#214237",
        fontSize: 100,
        right: 20,
        bottom: -15,
        zIndex: -1
    },
    iconImage: {
        position: "absolute",
        height: 50,
        width: 50,
        resizeMode: "contain",
        right: 20,
        top: -80
    }
});